set :application, "test"
set :deploy_to, File.expand_path(File.dirname(__FILE__)) + '/../../remote'

set :scm, :none
set :repository, '.'
set :deploy_via, :copy

role :app, 'localhost'
role :web, 'localhost'

set :user, "Roman"
set :use_sudo, false
set :default_shell, "bash -cl"

namespace(:deploy) do
  task(:finalize_update) { }
  task(:restart) { }
end
